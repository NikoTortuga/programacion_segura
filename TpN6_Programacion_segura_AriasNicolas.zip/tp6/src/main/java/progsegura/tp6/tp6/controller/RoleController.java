package progsegura.tp6.tp6.controller;

import progsegura.tp6.tp6.model.Role;
import progsegura.tp6.tp6.model.Permission;
import progsegura.tp6.tp6.service.IPermissionService;
import progsegura.tp6.tp6.service.IRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/api/roles")
public class RoleController {

    @Autowired
    private IRoleService roleService;

    @Autowired
    private IPermissionService permiService;

    @GetMapping
    // La lectura está disponible para usuarios con cualquiera de estos roles.
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<List<Role>> getAllRoles() {
        List<Role> roles = roleService.findAll();
        return ResponseEntity.ok(roles);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<Role> getRoleById(@PathVariable Long id) {
        Optional<Role> role = roleService.findById(id);
        return role.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    // Para crear roles se necesitan el rol ADMIN y la autoridad CREATE.
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('CREATE')")
    public ResponseEntity<Role> createRole(@RequestBody Role role) {
        Set<Permission> permiList = new HashSet<>();
        Permission readPermission;

        // Busca cada permiso por ID para asociar las entidades existentes.
        for (Permission per : role.getPermissionsList()) {
            readPermission = permiService.findById(per.getId()).orElse(null);
            if (readPermission != null) {
                permiList.add(readPermission);
            }
        }

        role.setPermissionsList(permiList);
        Role newRole = roleService.save(role);
        return ResponseEntity.ok(newRole);
    }

    @PatchMapping("/{id}")
    // Solo ADMIN puede modificar el rol y su lista de permisos.
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Role> updateRolePermissions(@PathVariable Long id, @RequestBody Role roleDetails) {
        Optional<Role> roleOpt = roleService.findById(id);
        if (roleOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Role role = roleOpt.get();

        if (roleDetails.getRole() != null && !roleDetails.getRole().isEmpty()) {
            role.setRole(roleDetails.getRole());
        }

        if (roleDetails.getPermissionsList() != null) {
            Set<Permission> permiList = new HashSet<>();
            // Reemplaza la lista de permisos por los permisos recibidos.
            for (Permission per : roleDetails.getPermissionsList()) {
                Permission readPermission = permiService.findById(per.getId()).orElse(null);
                if (readPermission != null) {
                    permiList.add(readPermission);
                }
            }
            role.setPermissionsList(permiList);
        }

        Role updatedRole = roleService.update(role);
        return ResponseEntity.ok(updatedRole);
    }
}