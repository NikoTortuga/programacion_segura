package progsegura.tp6.tp6;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class Tp6Application {

	public static void main(String[] args) {
		SpringApplication.run(Tp6Application.class, args);
	}

	@Bean
	public CommandLineRunner initData(JdbcTemplate jdbcTemplate, PasswordEncoder passwordEncoder) {
		return args -> {
			try {
				// Crea los datos iniciales de prueba solo cuando todavía no hay usuarios.
				Integer userCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Integer.class);
				if (userCount == null || userCount == 0) {
					// Define permisos, roles y las relaciones entre ellos.
					jdbcTemplate.execute("INSERT INTO permissions (id, permission_name) VALUES (1, 'READ'), (2, 'CREATE') ON DUPLICATE KEY UPDATE permission_name=VALUES(permission_name)");
					jdbcTemplate.execute("INSERT INTO roles (id, role) VALUES (1, 'ADMIN'), (2, 'USER') ON DUPLICATE KEY UPDATE role=VALUES(role)");
					jdbcTemplate.execute("INSERT IGNORE INTO roles_permissions (role_id, permission_id) VALUES (1, 1), (1, 2), (2, 1)");

					// Guarda la misma contraseña cifrada para los dos usuarios de prueba.
					String encodedPassword = passwordEncoder.encode("1234");
					jdbcTemplate.update(
						"INSERT INTO users (id, username, password, enabled, account_not_expired, account_not_locked, credential_not_expired) " +
						"VALUES (1, 'centro8', ?, true, true, true, true), (2, 'seguidor', ?, true, true, true, true) " +
						"ON DUPLICATE KEY UPDATE password=VALUES(password)",
						encodedPassword, encodedPassword
					);
					// Asigna ADMIN a centro8 y USER a seguidor.
					jdbcTemplate.execute("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (1, 1), (2, 2)");
				}
			} catch (Exception e) {
				// Si las tablas aún no se han creado en algún entorno de prueba específico, se omite silenciosamente
			}
		};
	}
}
