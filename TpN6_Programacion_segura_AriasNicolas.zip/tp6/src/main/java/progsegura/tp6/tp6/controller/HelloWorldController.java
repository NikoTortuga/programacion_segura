package progsegura.tp6.tp6.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

    @GetMapping("/holaseg")
    // Solo los usuarios con el rol ADMIN pueden acceder.
    @PreAuthorize("hasRole('ADMIN')")
    public String holaSeg() {
        return "¡Hola con Seguridad!";
    }

    @GetMapping("/holanoseg")
    // Endpoint público, disponible sin autenticación.
    public String holaNoSeg() {
        return "¡Hola SIN Seguridad!";
    }
}